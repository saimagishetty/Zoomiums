import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recent-new-articles',
  templateUrl: './recent-new-articles.component.html',
  styleUrls: ['./recent-new-articles.component.css']
})
export class RecentNewArticlesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
