import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer-toe',
  templateUrl: './footer-toe.component.html',
  styleUrls: ['./footer-toe.component.css']
})
export class FooterToeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
