import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gallery-type-one',
  templateUrl: './gallery-type-one.component.html',
  styleUrls: ['./gallery-type-one.component.css']
})
export class GalleryTypeOneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
