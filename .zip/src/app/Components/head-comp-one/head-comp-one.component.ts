import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-head-comp-one',
  templateUrl: './head-comp-one.component.html',
  styleUrls: ['./head-comp-one.component.css']
})
export class HeadCompOneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
