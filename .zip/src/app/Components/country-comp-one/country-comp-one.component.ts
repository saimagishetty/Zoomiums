import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-country-comp-one',
  templateUrl: './country-comp-one.component.html',
  styleUrls: ['./country-comp-one.component.css']
})
export class CountryCompOneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
