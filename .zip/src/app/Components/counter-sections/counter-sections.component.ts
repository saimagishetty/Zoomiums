import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-counter-sections',
  templateUrl: './counter-sections.component.html',
  styleUrls: ['./counter-sections.component.css']
})
export class CounterSectionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
