import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-country-line',
  templateUrl: './country-line.component.html',
  styleUrls: ['./country-line.component.css']
})
export class CountryLineComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
