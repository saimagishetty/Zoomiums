import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-post-visa',
  templateUrl: './post-visa.component.html',
  styleUrls: ['./post-visa.component.css']
})
export class PostVisaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
