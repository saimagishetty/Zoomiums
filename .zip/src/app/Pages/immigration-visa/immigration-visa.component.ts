import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-immigration-visa',
  templateUrl: './immigration-visa.component.html',
  styleUrls: ['./immigration-visa.component.css']
})
export class ImmigrationVisaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
