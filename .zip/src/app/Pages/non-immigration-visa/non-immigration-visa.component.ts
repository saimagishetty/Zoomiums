import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-non-immigration-visa',
  templateUrl: './non-immigration-visa.component.html',
  styleUrls: ['./non-immigration-visa.component.css']
})
export class NonImmigrationVisaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
